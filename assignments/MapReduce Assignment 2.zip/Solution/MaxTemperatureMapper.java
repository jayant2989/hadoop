import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class MaxTemperatureMapper 
extends Mapper<LongWritable, Text, Text, IntWritable> 
{
	private static final int MISSING = 9999;
	
	public void map(LongWritable key, Text value, Context context)
	throws IOException, InterruptedException 
	{
		String line = value.toString();
		if(line.length()>0)
		{
			String year = line.substring(15, 19);
			int airTemperature;
			if (line.charAt(40) == '+')
			{
				airTemperature = Integer.parseInt(line.substring(41, 45));
			} else 
			{
				airTemperature = Integer.parseInt(line.substring(40, 45));
			}
			
			if (airTemperature != MISSING ) 
			{
				context.write(new Text(year), new IntWritable(airTemperature));
			}
		}
	}
}