import java.io.IOException;  
import org.apache.hadoop.io.*; 
import org.apache.hadoop.mapreduce.*; 

 
public class Map extends Mapper<LongWritable, Text, Text, IntWritable> 
{ 

public void map(LongWritable key, Text value, Context context) 
throws IOException, InterruptedException 
{ 
String line=value.toString();
if(line.length()>0 && line!=null)
{
String tokens[]=line.split(",");
if(tokens.length>11)
{
	
	String Fbicode=tokens[14];
	
	if(Fbicode.equals("32"))
		context.write(new Text(Fbicode), new IntWritable(1));
}
}
}
}