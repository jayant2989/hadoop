
import java.io.IOException; 
import org.apache.hadoop.io.*; 
import org.apache.hadoop.mapreduce.*; 
public class Reduce extends Reducer<Text, Text, Text, IntWritable> { 
public void reduce(Text key, Iterable<Text> values, 
Context context) throws IOException, InterruptedException { 
	int count=0;
	for(Text record:values){
		String line=record.toString();
		String parts[]=line.split(",");
		if(parts[0].contains("THEFT")&&parts[1].equals("true")){
			count++;
		}
		
	}
	context.write(new Text("Total  arrest for theft in:"+key), new IntWritable(count));
	
}
}
