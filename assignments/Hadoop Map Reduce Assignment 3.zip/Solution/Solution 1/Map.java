


import java.io.IOException; 

import org.apache.hadoop.io.*; 
import org.apache.hadoop.mapreduce.*; 
 
public class Map extends Mapper<LongWritable, Text, Text, Text> 
{ 

public void map(LongWritable key, Text value, Context context) 
throws IOException, InterruptedException 
{ 
String line=value.toString();
if(line.length()>0 && line!=null)
{
String tokens[]=line.split(",");
if(tokens.length>11)
{
	String district=tokens[11];
	String Crime_type=tokens[5];
	String arrest=tokens[8];
	
	context.write(new Text(district), new Text(Crime_type+","+arrest));
}
}
}
}