import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;



public class Cleandata {

	public static class Map extends Mapper<LongWritable, Text, Text, NullWritable> {

@Override
protected void map(LongWritable key, Text value,Context context)
		throws IOException, InterruptedException {

	String s = value.toString();
	String s2="";
	String s1[]=s.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
	for(int i=0;i<s1.length;i++){
		if(s1[i].startsWith("\""))s1[i]=s1[i].replace(",","");

		s2=s2+s1[i]+",";			
	}


context.write(new Text(s2), NullWritable.get());
}

	}



	public static void main(String[] args) throws Exception {

	
		//JobConf conf = new JobConf(Cleandata.class);
		Job job=new Job();
		job.setJobName("wordcount");
		job.setJarByClass(Cleandata.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NullWritable.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(NullWritable.class);

		job.setMapperClass(Map.class);
		job.setNumReduceTasks(0);
	//	conf.setReducerClass(Reduce.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
  
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		
		job.waitForCompletion(true);

	}
}
